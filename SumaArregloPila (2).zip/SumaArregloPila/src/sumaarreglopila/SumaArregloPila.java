/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sumaarreglopila;

import java.util.Scanner;

/**
 *
 * @author pachoca
 */
public class SumaArregloPila {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner x= new Scanner(System.in);
        System.out.println("COMO TE LLAMAS ");
        String nombre;
        int  numb;
        nombre = x.nextLine();
        System.out.println("bienvenido "+nombre );
        System.out.println("por favor "+nombre+" diga el tamaño del arreglo: "); // escribir 
        int tam = x.nextInt();
      int[]arreglo = new int [tam];
      
      for(int i=0;i<tam;i++){
        System.out.println("por favor " +nombre+ " digite la posion del  " + (i+1) + " del arreglo");
        int pos= x.nextInt();
        arreglo[i] = pos;
        }
        System.out.println();
         System.out.println("los numeros escogidos escogidos por  " +nombre+ " fueron: ");
         for(int k:arreglo){
             System.out.print(k + " ");
             System.out.println();
           
             
         }
      System.out.println("muy bien "+nombre+" ahora  vamos a imprmir la pila "); 
      {
        int []pila = new int [tam];
        System.out.println();
        int po = 1;
        for(int pos = tam-1 ; pos>-1;pos--){
            System.out.println(nombre+" digite la posicion "+ po +" de la pila");
        int posi = x.nextInt();
        pila[pos]=posi;
        }
        System.out.println();
        System.out.println(nombre+ " la pila es: ");
        for(int d: pila){
            System.out.println(d +" ");
        }
          System.out.println("la suma de la pila y el arreglo es ");
          int suma = x.nextInt();
          suma = d + k;
          System.out.println("");
    }
}
    }
    
    

